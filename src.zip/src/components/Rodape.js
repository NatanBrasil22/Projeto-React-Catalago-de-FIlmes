import styles from './Rodape.module.css';

function Rodape() {
  return (
    <footer className={styles.rodape}>
      2026 - Natan Brasil - Autor
    </footer>
  );
}

export default Rodape;

import styles from './CardItem.module.css';

function CardItem({ imagem, titulo, categoria, descricao }) {
  return (
    <div className={styles.card}>
      <img src={imagem} alt={titulo} className={styles.imagem} />
      <h3>{titulo}</h3>
      <p className={styles.categoria}>{categoria}</p>
      <p>{descricao}</p>
    </div>
  );
}

export default CardItem;

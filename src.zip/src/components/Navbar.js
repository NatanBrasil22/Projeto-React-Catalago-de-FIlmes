import { Link } from 'react-router-dom';
import styles from './Navbar.module.css';

function Navbar() {
  return (
    <nav className={styles.navbar}>
      <h1 className={styles.logo}>Filmes Bem Avaliados pelo IMDB</h1>
      <ul className={styles.menu}>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/catalogo">Catálogo</Link></li>
        <li><Link to="/sobre">Sobre</Link></li>
      </ul>
    </nav>
  );
}

export default Navbar;

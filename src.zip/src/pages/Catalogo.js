import CardItem from '../components/CardItem';
import styles from './Catalogo.module.css';
import foto1 from '../assets/filme1.webp';
import foto2 from '../assets/filme2.webp';
import foto3 from '../assets/filme3.webp';

function Catalogo() {
  return (
    <main className={styles.container}>
      <h2>Catálogo</h2>
      <div className={styles.grid}>
        <CardItem
          imagem={foto1}
          titulo="Duna: Parte 2"
          categoria="Drama e Ficção científica"
          descricao="Em Duna: Parte 2, Paul Atreides se une a Chani e aos Fremen para buscar vingança contra os conspiradores que destruíram sua família. Enfrentando uma escolha entre o amor de sua vida e o destino do universo, ele tenta evitar um futuro terrível que só ele consegue prever."
        />
        <CardItem
          imagem={foto2}
          titulo="Hail Mary"
          categoria="Ficção científica, Aventura e Comédia"
          descricao="Ryland Grace, um professor de ciências, acorda sozinho numa nave espacial a milhões de quilômetros da Terra, sem memória de quem é ou o que está fazendo. Aos poucos descobre que é o único sobrevivente de uma missão desesperada: um microrganismo alienígena chamado Astrophage está consumindo a energia do Sol e a humanidade está prestes a se extinguir. Sozinho no espaço, ele precisa usar seu conhecimento científico para resolver o problema — e acaba fazendo uma amizade inesperada que pode ser a chave para salvar a Terra."
        />
        <CardItem
          imagem={foto3}
          titulo="The Godfather"
          categoria="Drama e Crime"
          descricao="Em 1945, Don Vito Corleone (Marlon Brando) é o chefe de uma poderosa família mafiosa de Nova York. Quando ele se recusa a entrar no tráfico de drogas, sua família sofre atentados. O filho mais novo, Michael (Al Pacino), herói de guerra que sempre se manteve afastado dos negócios do pai, é forçado a se envolver e acaba assumindo o controle do império familiar."
        />
      </div>
    </main>
  );
}

export default Catalogo;

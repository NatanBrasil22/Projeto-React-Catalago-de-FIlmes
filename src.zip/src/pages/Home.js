import styles from './Home.module.css';

function Home() {
  return (
    <main className={styles.container}>
      <h2>Bem Vindo,aqui voce encontra filmes bem avaliado no IMDB e Rotten Tomatoes</h2>
      <p>Clique em catalogo na Barra do Topo pra poder ser direcionado ao catalogo.</p>
    </main>
  );
}

export default Home;

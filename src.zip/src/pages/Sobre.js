import styles from './Sobre.module.css';

function Sobre() {
  return (
    <main className={styles.container}>
      <h2>Sobre o projeto</h2>
      <p>Este site foi feito em React para a disciplina de Laboratório de Desenvolvimento Web.</p>
      <p>Autor: Natan Brasil</p>
    </main>
  );
}

export default Sobre;
